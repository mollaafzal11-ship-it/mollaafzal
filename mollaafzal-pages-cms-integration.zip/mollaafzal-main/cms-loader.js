/* Pages CMS homepage content loader. Static HTML remains the SEO/no-JS fallback. */
(async function () {
  try {
    const response = await fetch('/cms/homepage.json', { cache: 'no-cache' });
    if (!response.ok) return;
    const data = await response.json();
    const setText = (selector, value) => {
      const node = document.querySelector(selector);
      if (node && typeof value === 'string' && value.trim()) node.textContent = value;
    };
    if (data.seo_title) {
      document.title = data.seo_title;
      document.querySelector('meta[property="og:title"]')?.setAttribute('content', data.seo_title);
    }
    if (data.seo_description) {
      document.querySelector('meta[name="description"]')?.setAttribute('content', data.seo_description);
      document.querySelector('meta[property="og:description"]')?.setAttribute('content', data.seo_description);
    }
    setText('.hero .eyebrow', data.hero_eyebrow);
    setText('.hero .hero-desc', data.hero_description);
    setText('.about-copy .eyebrow', data.about_eyebrow);
    const aboutParagraphs = document.querySelectorAll('.about-copy p');
    if (aboutParagraphs[0] && data.about_paragraph_1) aboutParagraphs[0].textContent = data.about_paragraph_1;
    if (aboutParagraphs[1] && data.about_paragraph_2) aboutParagraphs[1].textContent = data.about_paragraph_2;
    if (data.profile_image) {
      const portrait = [...document.querySelectorAll('img')].find(img => /Afzal, digital marketing professional/i.test(img.alt || ''));
      if (portrait) portrait.src = data.profile_image;
    }
  } catch (error) {
    console.warn('Pages CMS content could not be loaded; showing the static homepage.', error);
  }
})();
