# Pages CMS setup

1. Open https://pagescms.org/ and sign in with the GitHub account that owns this repository.
2. Install/authorize the Pages CMS GitHub App for `mollaafzal11-ship-it/mollaafzal`.
3. Open the repository in Pages CMS. It reads the root `.pages.yml` configuration.
4. Open **Homepage Content** to edit the homepage fields. Upload the profile image through the configured media folder (`portfolio_assets`).
5. Preview the site after a commit. Netlify should deploy from the connected GitHub repository as it does today.

Homepage content is stored in `cms/homepage.json`. The homepage retains its existing static HTML as a fallback for crawlers and if JavaScript is unavailable. The CMS values are applied by `cms-loader.js` after the JSON file loads.

The Services and Portfolio Projects collections are ready for future content entries. Existing service page URLs and current portfolio project cards remain in the homepage HTML; adding/editing collection entries does not automatically create or replace those pages/cards yet.
